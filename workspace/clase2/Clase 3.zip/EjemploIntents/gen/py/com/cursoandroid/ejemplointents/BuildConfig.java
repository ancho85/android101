/** Automatically generated file. DO NOT MODIFY */
package py.com.cursoandroid.ejemplointents;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}