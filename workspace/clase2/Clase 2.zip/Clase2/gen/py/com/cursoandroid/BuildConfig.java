/** Automatically generated file. DO NOT MODIFY */
package py.com.cursoandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}