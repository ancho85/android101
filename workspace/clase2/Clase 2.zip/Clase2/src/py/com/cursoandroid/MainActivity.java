package py.com.cursoandroid;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;
public class MainActivity extends Activity {
	int result;
	int valor1;
	int valor2;
	EditText n1;
	EditText n2;
	Button calcular; 
	@Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_main);
	        
	 
	       // hacemos un cast de los controles que tenemos en nuestro layout 
	        n1 =(EditText) findViewById(R.id.numero1);
	        n2 =(EditText) findViewById(R.id.numero2);
	        calcular =(Button) findViewById(R.id.calcular);
	        
	        // le indicamos a nuestro boton que hacer cuando hacemos click un click (manejo de eventos del objeto)
	        
	        calcular.setOnClickListener(new OnClickListener() {
	        	 
	             @Override
	             public void onClick(View v) {
	            
	            	 
	                      Toast.makeText(MainActivity.this, Integer.toString(calcular()), Toast.LENGTH_LONG).show();
	             }
	        });
		     
	}
	 private int calcular(){
    	 
         valor1 = Integer.parseInt(n1.getText().toString());
         valor2 = Integer.parseInt(n2.getText().toString());
         
         final RadioGroup rg = (RadioGroup)findViewById(R.id.gruporb);


         
         int id_rb_checket =rg.getCheckedRadioButtonId();
         
         switch (id_rb_checket){
	         case R.id.radioButtonSuma:
	        	 result = valor1 + valor2;
	        	 break;
	         case R.id.radioButtonResta:
	        	 //RESTA - no implementado
	        	 result = -100;
	        	 break;
	        //otros case.
         
         }
       	 //rg.clearCheck();
         return result;
	 } 


    
}
