/** Automatically generated file. DO NOT MODIFY */
package py.com.cursoandroid.clasesqlite;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}